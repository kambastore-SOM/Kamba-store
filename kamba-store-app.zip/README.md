# Kamba Store 🛍️

## Como fazer o deploy no Render.com (GRÁTIS)

### Passo 1 - Criar conta GitHub
1. Vai a **github.com**
2. Cria conta grátis com o teu Gmail

### Passo 2 - Criar repositório
1. Clica em **"New repository"**
2. Nome: `kamba-store`
3. Clica **"Create repository"**

### Passo 3 - Fazer upload dos ficheiros
1. Clica **"uploading an existing file"**
2. Faz upload de todos os ficheiros desta pasta
3. Clica **"Commit changes"**

### Passo 4 - Deploy no Render
1. Vai a **render.com**
2. Cria conta com o Gmail
3. Clica **"New Web Service"**
4. Liga ao teu repositório GitHub
5. Configurações:
   - Build Command: `npm install`
   - Start Command: `npm start`
6. Clica **"Create Web Service"**

### Pronto! ✅
O teu site fica em: `https://kamba-store.onrender.com`
As modificações ficam guardadas automaticamente para todos!

## Credenciais Manager
- Email: somplataforma@gmail.com
- Senha: kamba2025
