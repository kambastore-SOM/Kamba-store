const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'store.json');

app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Ensure data directory exists
if (!fs.existsSync(path.join(__dirname, 'data'))) {
  fs.mkdirSync(path.join(__dirname, 'data'));
}

// Default store data
const defaultData = {
  products: [
    {id:1,emoji:'👟',name:'Nike Air Force 1',cat:'Calçado',price:35000,img:null,desc:''},
    {id:2,emoji:'👕',name:'Camiseta Polo',cat:'Roupas',price:8500,img:null,desc:''},
    {id:3,emoji:'📱',name:'Samsung A15',cat:'Tecnologia',price:95000,img:null,desc:''},
    {id:4,emoji:'🎧',name:'Fones Bluetooth',cat:'Tecnologia',price:18000,img:null,desc:''},
    {id:5,emoji:'👜',name:'Mala Feminina',cat:'Acessórios',price:22000,img:null,desc:''},
    {id:6,emoji:'⌚',name:'Relógio Smartwatch',cat:'Tecnologia',price:45000,img:null,desc:''},
    {id:7,emoji:'👗',name:'Vestido Elegante',cat:'Roupas',price:19000,img:null,desc:''},
    {id:8,emoji:'🩳',name:'Calção Desportivo',cat:'Roupas',price:7500,img:null,desc:''},
    {id:9,emoji:'💻',name:'Laptop Lenovo',cat:'Tecnologia',price:280000,img:null,desc:''},
    {id:10,emoji:'🎮',name:'Joystick PS5',cat:'Games',price:42000,img:null,desc:''},
    {id:11,emoji:'👒',name:'Chapéu de Sol',cat:'Acessórios',price:5500,img:null,desc:''},
    {id:12,emoji:'🕶️',name:'Óculos Ray-Ban',cat:'Acessórios',price:28000,img:null,desc:''},
    {id:13,emoji:'👔',name:'Camisa Social',cat:'Roupas',price:12000,img:null,desc:''},
    {id:14,emoji:'🎒',name:'Mochila Escolar',cat:'Acessórios',price:16500,img:null,desc:''},
    {id:15,emoji:'📷',name:'Câmera Canon',cat:'Tecnologia',price:175000,img:null,desc:''},
    {id:16,emoji:'🛁',name:'Set Beleza Feminina',cat:'Beleza',price:13500,img:null,desc:''},
    {id:17,emoji:'🏋️',name:'Halter 10kg',cat:'Desporto',price:9500,img:null,desc:''},
    {id:18,emoji:'🩴',name:'Sandálias de Praia',cat:'Calçado',price:6000,img:null,desc:''},
    {id:19,emoji:'🖨️',name:'Impressora HP',cat:'Tecnologia',price:68000,img:null,desc:''},
    {id:20,emoji:'🛋️',name:'Almofada Decorativa',cat:'Casa',price:7000,img:null,desc:''},
    {id:21,emoji:'🍳',name:'Frigideira Antiaderente',cat:'Casa',price:11000,img:null,desc:''},
    {id:22,emoji:'🧴',name:'Creme Hidratante',cat:'Beleza',price:4500,img:null,desc:''},
    {id:23,emoji:'👠',name:'Salto Alto Elegante',cat:'Calçado',price:24000,img:null,desc:''},
    {id:24,emoji:'🎽',name:'Camisola de Treino',cat:'Desporto',price:9000,img:null,desc:''},
    {id:25,emoji:'📚',name:'Kit de Papelaria',cat:'Escola',price:5500,img:null,desc:''},
    {id:26,emoji:'🔌',name:'Carregador Universal',cat:'Tecnologia',price:8500,img:null,desc:''},
    {id:27,emoji:'🧢',name:'Boné Snapback',cat:'Acessórios',price:6500,img:null,desc:''},
    {id:28,emoji:'🧸',name:'Urso de Pelúcia',cat:'Brinquedos',price:7500,img:null,desc:''},
    {id:29,emoji:'🎁',name:'Caixa de Presente',cat:'Presentes',price:4000,img:null,desc:''},
    {id:30,emoji:'💄',name:'Batom + Gloss Set',cat:'Beleza',price:9500,img:null,desc:''},
  ],
  payMethods: ['Multicaixa Express','Transferência Bancária','Pagamento na Entrega'],
  paragens: ['Kilamba','11 de Novembro','Golf 2','Calemba 2'],
  contacts: [
    {type:'📞',label:'Telefone',value:'+244 923 000 000'},
    {type:'📍',label:'Endereço',value:'Luanda, Angola'}
  ],
  orderEmail: 'somplataforma@gmail.com',
  ejsSvcId: '',
  ejsTplId: '',
  ejsPubKey: '',
  payDetails: {mcx:'',iban:'',accName:''},
  logoImg: null,
  heroTitle: 'A Melhor Loja<br>de <span>Luanda</span> 🔥',
  heroSub: 'Produtos de qualidade entregues à sua paragem. Compre fácil, compre rápido.',
  aboutBox: '<strong>Kamba Store</strong> — uma loja criada pelo <strong>SOM Sistema Operacional de Multiplataforma</strong>, com o objetivo de facilitar a compra e venda em Luanda.',
  storeName: 'KAMBA <span>STORE</span>',
  fLogo: 'KAMBA <span>STORE</span>',
  cssRed: '#D62828',
  cssDark: '#141414',
  cssDark2: '#1E1E1E',
  cssBlack: '#0A0A0A',
};

// Load data
function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    }
  } catch(e) {}
  return defaultData;
}

// Save data
function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data), 'utf8');
}

// API: Get all store data
app.get('/api/data', (req, res) => {
  res.json(loadData());
});

// API: Save all store data (manager only)
app.post('/api/data', (req, res) => {
  const { password, data } = req.body;
  if (password !== 'kamba2025') {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  try {
    saveData(data);
    res.json({ success: true });
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
});

// API: Send order email (via EmailJS on client side, just log here)
app.post('/api/order', (req, res) => {
  console.log('New order:', JSON.stringify(req.body, null, 2));
  res.json({ success: true });
});

// Serve index.html for all routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`✅ Kamba Store running on port ${PORT}`);
});
